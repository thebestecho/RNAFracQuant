# This is the first part
# Those data are extracted from the original one
# They are not large, suitable for tests

# Users need to put all samples and a sample_sheet in one directory
# They should be in the same format
# The sample_sheet should include all the basic info about samples
setwd("~/")

library(stringr)
library(readxl)
library(dplyr)

# in case of users use different files to store data
read_data <- function(file,dir_in){
  files <- list.files(path=dir_in)
  file <- paste0(dir_in,"/",file)
  if (isTRUE(str_detect(files[1], pattern=".txt"))) {
      read_tsv(file=file,
        col_names = c("ORF","Count"),
        comment="__")
  }
  else if (isTRUE(str_detect(files[1], pattern=".xls"))) {
    read_excel(file=file,
               col_names = c("ORF","Count"),
               comment="__")
  } else {
      read_csv(file=file,
               col_names = c("ORF","Count"),
               comment="__")
  }
}

load_data <- function(dir_in){
  paste0(dir_in,"/Samplesheet.txt") %>%
    read_tsv(comment="#") %>%
    group_by(File,Sample,Condition,Fraction) %>%
    do(read_data(file=.$File[1],dir_in=dir_in)) %>%
    mutate(ORF=str_sub(ORF,end=-5))
}












