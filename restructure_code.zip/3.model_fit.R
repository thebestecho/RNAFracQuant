# This is the third part
library(tidyverse)  #1.3.0
library(tidybayes)  #2.1.1
library(rstan)  #2.19.3

setwd("~/restructured_codes")
model_tidy <- stan_model("model_tidy.stan")

tidy_fit <- function(tidydata, chains = 4, iter=1000,
                     control = list(adapt_delta=0.85),seed=39,
                     ...){
  tidydata <- compose_data(tidydata)
  tidy_sampling <- sampling(model_tidy,data=tidydata,iter=iter,control=control,seed=seed,
                            ...) %>% summary()
  data.frame(
      mixing.Sup=tidy_sampling$summary["mixing_sup","50%"],
      mixing.P100=tidy_sampling$summary["mixing_p100","50%"],
      lp.n_eff  =tidy_sampling$summary["lp__","n_eff"],
      lp.Rhat   =tidy_sampling$summary["lp__","Rhat"])
}
