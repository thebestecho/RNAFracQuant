# This is the first part Those data are extracted
# from the original one They are not large,
# suitable for tests

# Users need to put all samples and a sample_sheet
# in one directory They should be in the same
# format The sample_sheet should include all the
# basic info about samples
setwd("~/")

library(stringr)
library(readxl)
library(dplyr)
library(tidyr)
library(tidyverse)  #1.3.0
library(tidybayes)  #2.1.1
library(rstan)  #2.19.3
library(plyr)  #1.0.0

# in case of users use different files to store
# data
read_data <- function(file, dir_in)
{
  files <- list.files(path = dir_in)
  file <- paste0(dir_in, "/", file)
  if (isTRUE(str_detect(files[1], pattern = ".txt")))
  {
    read_tsv(file = file, col_names = c("ORF", 
                                        "Count"), comment = "__")
  } else if (isTRUE(str_detect(files[1], pattern = ".xls")))
  {
    read_excel(file = file, col_names = c("ORF", 
                                          "Count"), comment = "__")
  } else
  {
    read_csv(file = file, col_names = c("ORF", 
                                        "Count"), comment = "__")
  }
}

load_data <- function(dir_in)
{
  paste0(dir_in, "/Samplesheet.txt") %>% read_tsv(comment = "#") %>% 
    group_by(File, Sample, Condition, Fraction) %>% 
    do(read_data(file = .$File[1], dir_in = dir_in)) %>% 
    mutate(ORF = str_sub(ORF, end = -5))
}




# This is the second part Process data and make
# them tidy

ORFselect <- read_tsv("~/orf_coding_EW_select.txt")

# The data that I extracted do not meet the filter
# condition below So I use the original data here,
# it doesnt take much time to run actually
# You need to change the directory if the path is not correct
raw_data <- load_data(dir_in = "~/originalcodes/RNAFracQuant/data_in/TSP_count")


# function to get the TPM value
get_TPM <- function(rawdata)
{
  inner_join(rawdata, ORFselect) %>% group_by(Sample, 
                                              Condition, Fraction) %>% mutate(TPM = (Count/Length)/sum(Count/Length) * 
                                                                                1e+06) %>% select(Sample, Condition, Fraction, 
                                                                                                  ORF, Count, TPM)
}

# function to filter some unadmissiable data
filter_data <- function(rawdata)
{
  rawdataTPM <- get_TPM(rawdata) %>% filter(Fraction == 
                                              "Tot") %>% group_by(ORF) %>% summarise(d5 = sum(TPM > 
                                                                                                5), wd5 = (d5 == 4)) %>% filter(wd5) %>% .$ORF
}

filtered_data <- filter_data(rawdata = raw_data)

# get tidy data
tidydata <- get_TPM(rawdata = raw_data) %>% ungroup() %>% 
  select(Condition, Fraction, ORF, Count) %>% pivot_wider(names_from = Fraction, 
                                                          values_from = Count) %>% filter(ORF %in% filtered_data)





# This is the third part


# make sure that you know the position of the stan file
# I use sampling() rather than stan()
# I did not use fit= , when sampling
setwd("~/restructured_codes")
model_tidy <- stan_model("model_tidy.stan")

tidy_fit <- function(tidydata, chains = 4, iter = 1000, 
                     control = list(adapt_delta = 0.85), seed = 39, 
                     ...)
{
  tidydata <- compose_data(tidydata)
  tidy_sampling <- sampling(model_tidy, data = tidydata, 
                            iter = iter, control = control, seed = seed, 
                            ...) %>% summary()
  data.frame(mixing.Sup = tidy_sampling$summary["mixing_sup", 
                                                "50%"], 
             mixing.P100 = tidy_sampling$summary["mixing_p100",
                                                 "50%"], 
             lp.n_eff = tidy_sampling$summary["lp__", 
                                              "n_eff"], 
             lp.Rhat = tidy_sampling$summary["lp__", 
                                                                                                                                                                               "Rhat"])
}




# This is the fourth part call the function
# tidy_fit to get ratios for each condition I didnt
# find a useful function of package dplyr to
# replace the function ddply() of package plyr here

get_ratios <- function(tidydata)
{
  ddply(tidydata, ~Condition, tidy_fit)
}

# get the output: a data frame
ratios <- get_ratios(tidydata)
