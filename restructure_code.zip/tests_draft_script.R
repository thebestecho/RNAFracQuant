library(testthat)

# When the functions are not long, it is easier to not use testthat
# This is fun actually

raw_data <- load_data(dir_in = "~/originalcodes/RNAFracQuant/data_in/TSP_count")
test_that("the function of load data", {
  expect_match(typeof(raw_data), "list")
})


filtered_data <- filter_data(rawdata = raw_data)
test_that("the function of filter data", {
  expect_match(typeof(filtered_data), "character")
})


test_that("the format of tidy data", {
  expect_match(typeof(tidydata$ORF), "character")
})


ratios <- get_ratios(tidydata)
test_that("the output of getting ratios", {
  expect_equal(ratios$Condition[1], "30C")
})
