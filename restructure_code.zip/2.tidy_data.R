# This is the second part
# Process data and make them tidy

library(tidyr)
library(dplyr)

ORFselect <- read_tsv("~/orf_coding_EW_select.txt")

# The data that I extracted do not meet the filter condition below
# So I use the original data here, it doesnt take much time to run actually
raw_data <- load_data(dir_in="~/originalcodes/RNAFracQuant/data_in/TSP_count")


# function to get the TPM value
get_TPM <- function(rawdata){
  inner_join(rawdata,ORFselect) %>%
  group_by(Sample,Condition,Fraction) %>%
  mutate(TPM=(Count/Length)/sum(Count/Length)*1e6) %>%
  select(Sample,Condition,Fraction,ORF,Count,TPM)
}

# function to filter some unadmissiable data
filter_data <- function(rawdata){
  rawdataTPM <- get_TPM(rawdata) %>%
    filter(Fraction=="Tot") %>%
    group_by(ORF) %>%
    summarise(d5 = sum(TPM > 5),wd5=(d5==4)) %>%
    filter(wd5) %>%
    .$ORF
}

filtered_data <- filter_data(rawdata = raw_data)

# get tidy data
tidydata <- 
  get_TPM(rawdata=raw_data) %>%
  ungroup() %>%
  select(Condition,Fraction,ORF,Count) %>%
  pivot_wider(names_from = Fraction,values_from = Count) %>%
  filter(ORF %in% filtered_data)





