# This is the fourth part
# call the function tidy_fit to get ratios for each condition
# I didnt find a useful function of package dplyr to replace the function ddply() of package plyr here
library(plyr)  #1.0.0
get_ratios <- function(tidydata){
  ddply(tidydata,~Condition,tidy_fit)
}

ratios <- get_ratios(tidydata)
